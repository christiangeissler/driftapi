Run Standalone:

1) make sure the backend is runnning.
2) start the frontend via:

streamlit run app.py

(requires: pip install streamlit requests)