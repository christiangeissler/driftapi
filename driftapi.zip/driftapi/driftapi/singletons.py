import logging

from .settings import Settings

settings = Settings()
logger = logging.getLogger("uvicorn")